# Counter Voice: final synthetic dataset
All data synthetic (seeded). Images are real photos saved in images/ (Unsplash/Pexels free licenses), mapped via data/cafe_images.json.
- data/cafe.json: cafe, brand, menu (each item has image_slot -> data/cafe_images.json)
- data/customers.json: 60 personas (Persona Jury)
- data/ledgers.json: sample locked offers
- data/voice_utterances.json: 7 messy code-mixed inputs with traps
- data/audit_cases.json: 10 Fact Auditor eval cases (GOOD/BAD)
- data/historical_campaigns.json: 30 campaigns (synthetic rates, label as synthetic)
- data/image_prompts.json: prompts for gaps (logo, poster bg, keema pav)
- data/cafe_images.json: 35 image candidates with slot, credit, confidence
- gallery.html: preview all images before use
